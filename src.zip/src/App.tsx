import { useState } from "react";
import "./App.css";

import Header from "./components/Header";
import StatusPanel from "./components/StatusPanel";
import ConnectButton from "./components/ConnectButton";
import SignalCard from "./components/SignalCard";
import ProgressBar from "./components/ProgressBar";
import MissionLog from "./components/MissionLog";
import ScoreBoard from "./components/ScoreBoard";

type Question = {
  signal: string;
  options: string[];
  answer: string;
};

const QUESTIONS: Question[] = [
  {
    signal: "☍ ✦ △ ◈ ⌬",
    options: ["HELLO", "EARTH", "UNKNOWN", "DANGER"],
    answer: "HELLO",
  },
  {
    signal: "⌬ ☉ ☍ ✦ ◈",
    options: ["ALIEN", "FUTURE", "EARTH", "GALAXY"],
    answer: "ALIEN",
  },
  {
    signal: "◈ △ ✦ ☉ ☍",
    options: ["MESSAGE", "ERROR", "SYSTEM", "RETURN"],
    answer: "MESSAGE",
  },
  {
    signal: "☉ ☉ ✦ △ ⌬",
    options: ["ENERGY", "STAR", "LIGHT", "POWER"],
    answer: "ENERGY",
  },
  {
    signal: "△ ✦ ◈ ☍ ☉",
    options: ["WARNING", "ESCAPE", "ATTACK", "RETURN"],
    answer: "WARNING",
  },
];

export default function App() {
  const [connected, setConnected] = useState(false);
  const [credits, setCredits] = useState(10);
  const [score, setScore] = useState(0);
  const [played, setPlayed] = useState(0);
  const [history, setHistory] = useState<boolean[]>([]);
  const [message, setMessage] = useState(
    "Connect your wallet to start."
  );
  const [answered, setAnswered] = useState(false);

  const [current, setCurrent] = useState(
    Math.floor(Math.random() * QUESTIONS.length)
  );

  const question = QUESTIONS[current];

  const transmission = 10000 + played;

  const difficulty = Math.min(
    5,
    Math.max(1, Math.floor(played / 2) + 1)
  );

  const reward = difficulty * 10;

  function connectWallet() {
    setConnected(true);
    setMessage("Wallet Connected.");
  }

  function receiveSignal() {
    if (credits <= 0) {
      setMessage("No UTC remaining.");
      return;
    }

    if (!answered && played > 0) {
      setMessage("Decode current signal first.");
      return;
    }

    setCredits((c) => c - 1);

    setAnswered(false);

    setPlayed((p) => p + 1);

    setCurrent(
      Math.floor(Math.random() * QUESTIONS.length)
    );

    setMessage("Transmission received.");
  }

  function choose(option: string) {
    if (answered) return;

    const correct = option === question.answer;

    setAnswered(true);

    setHistory((prev) => [...prev, correct]);

    if (correct) {
      setScore((s) => s + reward);

      setMessage(
        `Correct! +${reward} XP`
      );
    } else {
      setMessage(
        `Wrong! Correct answer: ${question.answer}`
      );
    }
  }

  const correctCount = history.filter(Boolean).length;

  const accuracy =
    history.length === 0
      ? 0
      : Math.round(
          (correctCount / history.length) * 100
        );

  let level = "RECRUIT";

  if (score >= 30) level = "JUNIOR";
  if (score >= 60) level = "SENIOR";
  if (score >= 100) level = "ELITE";
  if (score >= 160) level = "LEGEND";

  return (
    <div className="app">
      <div className="terminal">

        <Header
          title="DECODE THE SIGNAL"
          year="YEAR 2148"
        />

        <div className="story">
          <p>Alien transmissions are reaching Earth.</p>

          <p>
            Every transmission requires 1 UTC.
          </p>
        </div>

        <StatusPanel
          status={connected ? "ONLINE" : "OFFLINE"}
          wallet={
            connected
              ? "CONNECTED"
              : "NOT CONNECTED"
          }
          balance={
            connected
              ? `${credits} UTC`
              : "---"
          }
        />

        {!connected ? (
          <div
            style={{ marginTop: 30 }}
            onClick={connectWallet}
          >
            <ConnectButton
              text="CONNECT WALLET"
            />
          </div>
        ) : (
          <>
            <ProgressBar
              current={played}
              total={10}
            />

            <SignalCard
              transmission={transmission}
              signal={question.signal}
              difficulty={difficulty}
              reward={reward}
            />

            <button
              style={{ marginTop: 25 }}
              onClick={receiveSignal}
            >
              PAY 1 UTC & RECEIVE SIGNAL
            </button>

            <div
              style={{
                display: "grid",
                gap: 15,
                marginTop: 25,
              }}
            >
              {question.options.map((option) => (
                <button
                  key={option}
                  disabled={answered}
                  onClick={() =>
                    choose(option)
                  }
                >
                  {option}
                </button>
              ))}
            </div>

            <div
              style={{
                marginTop: 25,
                border: "1px solid #00ff99",
                padding: 20,
              }}
            >
              <strong>
                SYSTEM MESSAGE
              </strong>

              <p
                style={{
                  marginTop: 10,
                }}
              >
                {message}
              </p>
            </div>

            <MissionLog history={history} />

            <ScoreBoard
              score={score}
              accuracy={accuracy}
              level={level}
            />

            {played >= 10 && (
              <div
                style={{
                  marginTop: 30,
                  border: "2px solid gold",
                  padding: 25,
                  textAlign: "center",
                }}
              >
                <h1>
                  MISSION COMPLETE
                </h1>

                <h2
                  style={{
                    marginTop: 20,
                  }}
                >
                  FINAL SCORE
                </h2>

                <h1>{score} XP</h1>

                <h2>
                  Accuracy {accuracy}%
                </h2>

                <h2>
                  Rank {level}
                </h2>
              </div>
            )}
          </>
        )}

      </div>
    </div>
  );
}